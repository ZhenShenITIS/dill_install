#! /bin/bash

_ROOT="$(pwd)" && cd "$(dirname "$0")" && ROOT="$(pwd)"
ROOT=$(cd "$(dirname "$0")";pwd)
PJROOT="$ROOT"
DILL_DIR=$PJROOT

tlog() {
    echo "$(date '+%Y-%m-%d %H:%M:%S %Z') > $*"
}

dill_proc=$(ps axu | grep -v grep | grep dill-node | grep alps | head -n 1)
if [ -z "$dill_proc" ];then
    echo "Dill node not running. Unable to exit validator"
    exit 1
fi
rpc_port=4000

if echo "$dill_proc" | grep -q -- "--rpc-port"; then
    rpc_port=$(echo $dill_proc | awk -F "--rpc-port" '{print $2}' | awk '{print $1}')
fi

$DILL_DIR/dill-node validator exit --wallet-dir=$DILL_DIR/keystore --beacon-rpc-provider=127.0.0.1:$rpc_port --wallet-password-file=$DILL_DIR/validator_keys/keystore_password.txt
