#! /bin/bash

_ROOT="$(pwd)" && cd "$(dirname "$0")" && ROOT="$(pwd)"
ROOT=$(cd "$(dirname "$0")";pwd)
PJROOT="$ROOT"

tlog() {
    echo "$(date '+%Y-%m-%d %H:%M:%S %Z') > $*"
}

dill_proc=$(ps axu | grep -v grep | grep dill-node | grep alps)
if [ -z "$dill_proc" ];then
    echo "Dill node not running. No need to stop"
    exit 0
fi

ps aux | grep -i dill | grep -v grep | grep -v stop | grep -v start | awk '{print $2}' | xargs kill

for i in {1..15}; do
    sleep 2
    dill_proc=$(ps axu | grep -v grep | grep dill-node | grep alps)
    if [ -z "$dill_proc" ]; then
        echo "Dill node stopped now"
        exit 0
    else
        echo "Dill node still running"
    fi
done

echo "Dill node stop failed!!! 😢"
exit 1