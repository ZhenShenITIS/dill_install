#! /bin/bash

./dill-node accounts list --wallet-dir=./keystore --wallet-password-file=./validator_keys/keystore_password.txt
